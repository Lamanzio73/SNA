
#pip install python-twitter
#pip install TextBlob

### https://www.linkedin.com/pulse/appunti-sparsi-di-machine-learning-5-sentiment-con-python-rodolfi-
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from textblob import TextBlob
import nltk
#import db_sqlite as sqlite
import sqlite3
import re
import string
import time

#from sentita import calculate_polarity

nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')
nltk.download('brown')

class sentiment_brand(object):
    def __int__(self):
        print('sentiment_brand')

    def process_messages(self, path=None, file_img=None, file_gfx=None, data_msg=None, dictionary=None, title=None, max_words=None, max_font_size=None):
#        array_tweet = " ".join(array_tweet)
        print(file_img)
        if len(file_img.split('_')) == 5:
            _, file, date_from, date_to, _ = file_img.split('_')
        else:
            file, date_from, date_to, _ = file_img.split('_')

        raw_elem={'brand':[],'no_words':[],'date':[],'sem_x':[],'sem_y':[]}
        regex = re.compile('[%s]' % re.escape(string.punctuation+'،‘"؛\'#'))
    
        for line in data_msg:
            line = line.lower()
            line = regex.sub(' ', line)
            converted    = True
            polarity     = 0.0
            subjectivity = 0.0
            print('translate:', len(line), 'words')
            tweet_tradotto=""
            try:
                testimonial=TextBlob(str(line))
                tweet_tradotto=testimonial.translate(from_lang='it',to='en')
            except Exception as ee:
                print ('Errore: ', ee)
                converted = False
            time.sleep(1)

            if converted:
                print('translated', len(tweet_tradotto), 'words')
                testimonial = TextBlob(str(tweet_tradotto))
                testimonial.tags
                testimonial.noun_phrases
                #calcolo del sentiment
                testimonial.sentiment
                polarity = testimonial.sentiment.polarity
                subjectivity = testimonial.sentiment.subjectivity
                #Polarity è l'emozione espressa in una frase: -1 negativo 0 neutro +1 positivo
                print(polarity )
                #Subjectivity indica se quanto è espresso è oggettivo 0 oppure soggettivo 1
                print(subjectivity)

            raw_elem['brand'].append(title.replace('_',' '))
            raw_elem['no_words'].append(len(tweet_tradotto))
            raw_elem['date'].append(date_to)
            raw_elem['sem_x'].append(polarity)
            raw_elem['sem_y'].append(subjectivity)

        engine = sqlite3.connect(path+'SBS.db', check_same_thread=False)
        if len(raw_elem['brand']) >0:
#            print('Save to DB...')
            raw_elem1 = pd.DataFrame(raw_elem)
#            print('Save to DB1')
            raw_elem1.to_sql('tw_sentiment', con=engine, if_exists='append')
#            print('Save to DB2')
        engine.close()


    def sentiment_draw(self, path):

        colors = {'salvini':'red', 'conte':'blue', 'giuseppe conte':'blue', 'maio':'green', 'di maio':'green', 'zingaretti':'yellow', 'berlusconi':'gray'}
        engine = sqlite3.connect(path+'SBS.db', check_same_thread=False)
        try:
            sql    = 'select distinct (date) from %s;' % ('tw_sentiment')
            sem_score = pd.read_sql_query(sql, con=engine)
            dates = sem_score.date
        except Exception as e:
            print('sql-sentiment_draw', e)
        
        for date in dates:
            sql  = 'select brand, no_words, date, sem_x, sem_y from %s where date="%s";' % ('tw_sentiment', date)
#            print(sql)
            rows = pd.read_sql_query(sql, con=engine)
            brands  = rows.brand
            no_words = rows.no_words
            dates   = rows.date
            sem_xs  = rows.sem_x
            sem_ys  = rows.sem_y
            
            for idx in range(len(brands)):
                print(brands[idx])
                x = sem_xs[idx]
                y = sem_ys[idx]
                plt.scatter(x, y, marker = "o", color = colors[brands[idx]], label=brands[idx])
                plt.xlim([-1, 1])
                plt.ylim([0, 1])
                plt.xlabel('x')
                plt.ylabel('y')
        
            plt.legend()
            plt.title("Sentiment Analysis"+'-'+dates[0])
            plt.xlabel("Polarity") 
            plt.ylabel("Subjectivity")
            plt.savefig(path+dates[0]+'_S'+'.png', transparent=False)
            plt.show()  
            plt.close('all')
        engine.close()

###########################################################################################
#BASE_PATH = 'D:/temp/SNA3/'
#file='giuseppe_conte.db'
#
#tables = ['rtw_messages','tw_messages']
#dt_from = '2019-03-01'
#dt_to = '2019-03-10'
#total_sql = []
#total_msg = []
#end = 0
#
#try:
#    db_engine = sqlite.db_sqlite(BASE_PATH+'giuseppe_conte.db')
#    engine    = db_engine.get_db_file_connection()
#    for table in tables:
#        sql = ' select "message" from "%s" where "date" BETWEEN \'%s\' AND \'%s\';' % (table, dt_from, dt_to)
#        ret_sql    = pd.read_sql_query(sql, con=engine)
#        ret_sql = ret_sql.message
#        no_of_message2 = len(ret_sql)
#        total_sql.extend(ret_sql)
#        print('no_of_message2', no_of_message2)
#    engine.close()
#except Exception as e:
#    print (e)
#    engine.close()
#
#stmt = sentiment_brand()
##stmt.sentiment_brand(BASE_PATH, 'sentiment.png', total_msg, 'Conte')
#stmt.process_messages(path=BASE_PATH, file_img='sentiment.png', 
#                          file_gfx='sentiment.gexf', data_msg=total_sql, 
#                          dictionary='italian', title='giuseppe_conte', 
#                          max_words=200, max_font_size=40)
#
###########################################################################################
#BASE_PATH = 'E:/tmp/SNA2/'
#stmt = sentiment_brand()
#stmt.sentiment_draw(BASE_PATH)




