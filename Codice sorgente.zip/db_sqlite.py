import sqlite3

db_path = ''
db_name = ''
db_full_path = ''
conn = None

class db_sqlite(object):
    def __init__(self, path):
        self.db_full_path = path

    def get_db_file_connection(self):

        #if (os.path.exists(self.db_full_path)):
        self.conn = sqlite3.connect(self.db_full_path, check_same_thread=False)
        return self.conn

    def create_tables(self):
        c = self.conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS tw_messages (
                date         text not null, 
                name         text not null,
                screen_name  text, 
                user_id      text, 
                re_tweet_no  integer, 
                re_tweet_uri text, 
                message      text
                )'''        
        )        

        c.execute('''CREATE TABLE IF NOT EXISTS rtw_messages (
                date         text not null, 
                name         text not null,
                screen_name  text, 
                user_id      text, 
                re_tweet_no  integer, 
                re_tweet_uri text, 
                message      text
                )'''        
        )        

        c.execute('''CREATE TABLE IF NOT EXISTS tw_profiles (
                id          integer not null, 
                screen_name text not null, 
                name        text not null,
                created_at  text, 
                description text, 
                followers_count text, 
                statuses_count text, 
                url      text, 
                location text, 
                lang text
                )'''
        )

        c.execute('''CREATE TABLE IF NOT EXISTS sbs_data (
                date         text not null, 
                brand        text not null,
                prevalence   real, 
                diversity    real, 
                connectivity real, 
                sbs          real
                )'''
        )

        self.conn.commit()
        c.close()

    def insert_on_tw_messages(self, tw_searces):
        c = self.conn.cursor()
        try:

            insert = ('''insert into tw_messages 
                      ('date','name','screen_name','user_id','re_tweet_no','re_tweet_uri','message')      
                      values (?, ?, ?, ?, ?, ?, ?);'''
                      )
            print(tw_searces)

            for data in tw_searces:
                
                data_tuple = (data['date'],
                            data['name'],
                            data['screen_name'],
                            data['user_id'],
                            data['re_tweet_no'],
                            data['re_tweet_uri'],
                            data['message']
                            )
                print(insert)
                print(data_tuple)
                c.execute(insert, data_tuple)
                
            self.conn.commit()
        except Exception as e:
            print('error on insert_on_tw_messages',e)
            self.conn.rollback()
        c.close()
        
    def insert_on_rtw_messages(self, tw_searces):
        c = self.conn.cursor()
        try:

            insert = ('''insert into rtw_messages 
                      ('date', 'name', 'screen_name', 'user_id', 're_tweet_no', 're_tweet_uri', 'message')
                      values (?, ?, ?, ?, ?, ?, ?);'''
                      )

            for data in tw_searces:
                data_tuple = (data['date'],
                            data['name'],
                            data['screen_name'],
                            data['user_id'],
                            data['re_tweet_no'],
                            data['re_tweet_uri'],
                            data['message']
                            )

                c.execute(insert, data_tuple)
            self.conn.commit()
        except Exception as e:
            print(e)
            self.conn.rollback()
        c.close()

    def insert_on_tw_profiles(self, tw_profiles):
        c = self.conn.cursor()
        try:

            insert = ('''insert into tw_profiles 
                      ('id', 'screen_name', 'name', 'created_at', 'description', 'followers_count', 'statuses_count', 'url', 'location', 'lang')
                      values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);'''
                      )

            for data in tw_profiles:

                data_tuple = (data['id'],
                            data['screen_name'],
                            data['name'],
                            data['created_at'],
                            data['description'],
                            data['followers_count'],
                            data['statuses_count'],
                            data['url'],
                            data['location'],
                            data['lang']
                            )

                c.execute(insert, data_tuple)
            self.conn.commit()
        except Exception as e:
            print(e)
            self.conn.rollback()
        c.close()

    def insert_on_sbs_data(self, sbs_data,brands, date):
        c = self.conn.cursor()
        try:
            insert = ('''insert into sbs_data 
                      ('date', 'brand', 'prevalence', 'diversity', 'connectivity', 'sbs')
                      values (?, ?, ?, ?, ?, ?);'''
                      )
            
            for brand in brands:
                data_tuple = (date,
                            brand,
                            sbs_data['PREVALENCE'][brand], 
                            sbs_data['DIVERSITY'][brand], 
                            sbs_data['CONNECTIVITY'][brand], 
                            sbs_data['SBS'][brand]
                            )

                c.execute(insert, data_tuple)
            self.conn.commit()
        except Exception as e:
            print(e)
            self.conn.rollback()
        c.close()

    def select_on_tables(self):
        print('select')


#db_path = 'C:/Basket/temp/SNA/'
#db_name = 'dimaio'
#d = db_sqlite(db_path, db_name)
#d.get_db_file_connection()
#d.create_tables()
#sbs={'PREVALENCE':{'a':2,'b':3},'DIVERSITY':{'a':3,'b':4},'CONNECTIVITY':{'a':5,'b':6},'SBS':{'a':7,'b':8}}
#brands=['a','b']
#data = '2019-04-01'
#d.insert_on_sbs_data(sbs, brands, data)
       
