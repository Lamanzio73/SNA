import re
import nltk
import string
from nltk.stem.snowball import SnowballStemmer

import networkx as nx
import matplotlib.pyplot as plt
import pandas as pd
import sbs_engine as sbs
import warnings
import db_sqlite as sqlite


# Input data files check
from subprocess import check_output

class word_association(object):
    def __init__(self):
        print('network_brand')

    def process_messages(self, path=None, dt=None, data_msg=None, dictionary=None, title=None, co_occurrence=None):

        warnings.filterwarnings('ignore')
        brands = title
        print('brands', brands[0])
        sbs1 = sbs.SBS()
        print('data_msg no:', len(data_msg))
        texts = sbs1.clean_corpus(brands, dictionary, data_msg)
        print('texts no:', len(texts))
        network = sbs1.prepare_network_graph(brands, texts, co_occurrence)

        data_msg_f   = network['original']
        data_msg_n   = network['filtered']

        print('len(data_msg_f.nodes())', len(data_msg_f.nodes()))
        print('len(data_msg_n.nodes())', len(data_msg_n.nodes()))

        data_msg = data_msg_f
        #Definisco le due sottoreti; ciascuna contiene gli archi con il brand;
        subnet_1=nx.Graph([(u, v, data) for (u, v, data) in data_msg.edges(data=True) if u == brands[0] or v == brands[0]])
        subnet_2=nx.Graph([(u, v, data) for (u, v, data) in data_msg.edges(data=True) if u == brands[1] or v == brands[1]])
        #Dainternet:If you want a new graph of the difference of G and H with with the attributes (including edge data) from G use remove_nodes_from() as follows:
        # R = G.copy()
        # R.remove_nodes_from(n for n in G if n in H)
        plt.figure(figsize=(12,12))
        options = {
            'edge_color': '#FFDEA2',
            'width': 2,
            'with_labels': True,
            'font_weight': 'regular',
        }
        print('len(subnet_1.nodes())', len(subnet_1.nodes()))

        R_1 = subnet_1.copy()
        R_1.remove_nodes_from(n for n in subnet_1  if n in subnet_2 and n != brands[0])
        print('len(R_1.nodes())', len(R_1.nodes()))
        if len(R_1.nodes()) > 1:
            subnet_1=nx.DiGraph(((source, target, attr) for source, target, attr in R_1.edges(data=True) if attr['weight'] > 5))
            print('len subnet_1', len(subnet_1.nodes()))
            nx.draw(subnet_1, pos=nx.spring_layout(subnet_1, k=0.25, iterations=50), **options)
            nx.write_gexf(subnet_1, path+dt+'_'+brands[0]+'_vs_'+brands[1]+".gexf")
            ax = plt.gca()
            ax.collections[0].set_edgecolor("#f09494") 
            plt.savefig(path+dt+'_'+brands[0]+'_vs_'+brands[1]+'.png', format="png")
            plt.show()

        R_2 = subnet_2.copy()
        R_2.remove_nodes_from(n for n in subnet_2  if n in subnet_1 and n != brands[1])
        if len(R_2.nodes()) > 1:
            subnet_2=nx.DiGraph(((source, target, attr) for source, target, attr in R_2.edges(data=True) if attr['weight'] > 5))
            print('len subnet_2', len(subnet_2.nodes()))
            nx.draw(subnet_2, pos=nx.spring_layout(subnet_2, k=0.25, iterations=50), **options)
            nx.write_gexf(subnet_2, path+dt+'_'+brands[1]+'_vs_'+brands[0]+".gexf")
            ax = plt.gca()
            ax.collections[0].set_edgecolor("#FFDEA2") 
            plt.savefig(path+dt+'_'+brands[1]+'_vs_'+brands[0]+'.png', format="png")

        plt.show()
        plt.close('all')

###########################################################################################
#BASE_PATH = 'C:/Basket/temp/SNA2/'
#file='giuseppe_conte.db'
##file='salvini.db'
#
#tables = ['rtw_messages','tw_messages']
#dt_from = '2019-03-01'
#dt_to = '2019-04-10'
#total_sql = []
#try:
#    db_engine = sqlite.db_sqlite(BASE_PATH+file)
#    engine    = db_engine.get_db_file_connection()
#    for table in tables:
#        sql = ' select "message" from "%s" where "date" BETWEEN \'%s\' AND \'%s\';' % (table, dt_from, dt_to)
#        ret_sql    = pd.read_sql_query(sql, con=engine)
#        ret_sql = ret_sql.message
#        no_of_message2 = len(ret_sql)
#        total_sql.extend(ret_sql)
#    engine.close()
#except Exception as e:
#    print (e)
#    engine.close()
#
##data = ' '.join(total_sql)
#data = total_sql
#ntrk = word_association()
#ntrk.process_messages(path=BASE_PATH, dt=dt_to, data_msg=data, dictionary='italian', title=['conte', 'salvini'], co_occurrence=5)

