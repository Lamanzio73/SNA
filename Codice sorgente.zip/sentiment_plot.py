# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import pandas as pd
import sqlite3
import matplotlib.pyplot as plt


BASE_PATH='D:/temp/SNA5/'
filename='semantic_result.txt'

raw_elem={'brand':[],'no_messages':[],'date':[],'sem_x':[],'sem_y':[]}
with open(BASE_PATH+filename,'r') as fd:
    for elem in fd:
        brand, msg1, msg2, date, time, x, y = elem.strip().split(' ')
        raw_elem['brand'].append(brand.replace('_',' '))
        raw_elem['no_messages'].append(int(msg1)+int(msg2))
        raw_elem['date'].append(date)
        raw_elem['sem_x'].append(float(x))
        raw_elem['sem_y'].append(float(y))
fd.close()
#print(raw_elem)    
raw_elem = pd.DataFrame(raw_elem)
engine = sqlite3.connect(BASE_PATH+'sentiment.db', check_same_thread=False)
raw_elem.to_sql('tw_sentiment', con=engine, if_exists='replace')
raw_elem.to_csv(BASE_PATH+'sentiment.csv', sep='|', encoding = "UTF-8", header=True, index=False)

colors = {'salvini':'red', 'giuseppe conte':'blue', 'di maio':'green', 'zingaretti':'yellow', 'berlusconi':'gray'}

sql    = 'select distinct (date) from %s;' % ('tw_sentiment')
brands = pd.read_sql_query(sql, con=engine)
dates = brands.date
for date in dates:
    sql  = 'select brand, no_messages, date, sem_x, sem_y from %s where date="%s";' % ('tw_sentiment', date)
    print(sql)
    rows = pd.read_sql_query(sql, con=engine)
    brands  = rows.brand
    no_msgs = rows.no_messages
    dates   = rows.date
    sem_xs  = rows.sem_x
    sem_ys  = rows.sem_y
    
    for idx in range(len(brands)):
        print(brands[idx])
        x = sem_xs[idx]
        y = sem_ys[idx]
        plt.scatter(x, y, marker = "o", color = colors[brands[idx]], label=brands[idx])
        plt.xlim([-2, 2])
        plt.ylim([0, 2])
        plt.xlabel('x')
        plt.ylabel('y')

    plt.legend()
    plt.title("Sentiment Analysis"+'-'+dates[0])
    plt.xlabel("Polarity") 
    plt.ylabel("Subjectivity")
    plt.savefig(BASE_PATH+dates[0]+'.png', transparent=False)
    plt.show()  

engine.close()

