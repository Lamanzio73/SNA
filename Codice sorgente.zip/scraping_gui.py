import PySimpleGUI as sg
import twitter_scrap as tws
import sbs_engine as sbs
import db_sqlite as sqlite
import word_cloud as wcl
import sentiment_brand as stmtb
import twitter_api as tw_api
import graphic as splot
import network_brand as ntwk
import plot_clustered as pltc
import word_association as word_ass
import os
import re
import pandas as pd
import time
import logging
import threading
from datetime import datetime, timedelta

regex = re.compile(r'[ #@!"£$%&?*+èéç°§ù]')
BASE_PATH   = ''
tweets_data = None
DB_ext      = '.db'
ACCESS_TOKEN    = '1147954133502181376-d9wPoocIUtDFvCrdbuVxL7qC8H942o'
ACCESS_SECRET   = 'aCjrs6YlDyb0tgEmMponknZXmhWpOUmsWDlQWCDPhWcUZ'
CONSUMER_KEY    = 'F4THZsf1pJshNnqOQtdnEd3yP'
CONSUMER_SECRET = '04QJMxm5Y4iWyFHsWdfCE8INMOcOEsjsRelhHf6AprL7Ap6UWJ'
comment     = ''
tw_message  = 'tw_messages'
rtw_message = 'rtw_messages'
tables      = [rtw_message,tw_message]
tw_profiles ='tw_profiles'

class Graphic_interface(object):
    def __init__(self):
        print('Init')
        self.DB_ext='.db'
        self.tw_message  = 'tw_messages'
        self.rtw_message = 'rtw_messages'
        self.tables      = [rtw_message,tw_message]
        self.tw_profiles ='tw_profiles'


    def start_it(self):
        window = sg.Window('Columns') 
        
        sna = 'salvini;conte;maio;zingaretti;berlusconi'
        search_f_date = '2019-03-01'
        search_t_date = '2019-09-30'
        query         = 'Di Maio'

        col_search = [[sg.Text('String Search:'      , size=(20, 1)), sg.Input(query, key='query')],
                      [sg.Text('Date From (Y-M-D):'  , size=(20, 1)), sg.Input(search_f_date, key='dtfrom')],
                      [sg.Text('Date To   (Y-M-D):'  , size=(20, 1)), sg.Input(search_t_date, key='dtto')],
                      [sg.Text('Deep Cycle:'         , size=(20, 1)), sg.Input(1000, key='deep')]
                      ]
        
        # Column layout
        col_execution = [[sg.Text('Twitter Configurations:')],
                         [sg.Text('Access Token:' , size=(10, 1)), sg.Input('1147954133502181376-d9wPoocIUtDFvCrdbuVxL7qC8H942o', key='a_token')],
                         [sg.Text('Access Secret:', size=(10, 1)), sg.Input('aCjrs6YlDyb0tgEmMponknZXmhWpOUmsWDlQWCDPhWcUZ', key='a_secret')],
                         [sg.Text('Cust. Key:'    , size=(10, 1)), sg.Input('F4THZsf1pJshNnqOQtdnEd3yP', key='c_key')],
                         [sg.Text('Cust Secret:'  , size=(10, 1)), sg.Input('04QJMxm5Y4iWyFHsWdfCE8INMOcOEsjsRelhHf6AprL7Ap6UWJ', key='c_secret')]
                         #[sg.Text('User Name:'    , size=(10, 1)), sg.Input('.fullname')],
                         #[sg.Text('User Id:'      , size=(10, 1)), sg.Input('.username')],
                         #[sg.Text('Tweet Text:'   , size=(10, 1)), sg.Input('.tweet-text')],
                         #[sg.Text('Date Time:'    , size=(10, 1)), sg.Input('._timestamp')],
                         #[sg.Text('Re Tweets:'    , size=(10, 1)), sg.Input('.ProfileTweet-actionCountForPresentation')],
                         #[sg.Text('Tweet Uri:'    , size=(10, 1)), sg.Input('data-permalink-path')]
                         ]

        # Column layout
        col_api = [[sg.Text('Profile Name:' , size=(15, 1)), sg.Input('', key='p_name')],
                   [sg.Text('Query:'        , size=(15, 1)), sg.Input('', key='p_query')],
#                   [sg.Text('Deep:'         , size=(15, 1)), sg.Input(5, key='p_deep')],
                   [sg.Radio('Profile By files', "RADIO1", default=True, key='p_radio1'), sg.Radio('Profile by Name', "RADIO1", key='p_radio2')]
                   ]
        
        col_sbs = [[sg.Text('Brands (A;B;C...):'  , size=(15, 1)), sg.Input(sna,  key='brands')],
                   [sg.Text('Date Start (Y-M-D):' , size=(15, 1)), sg.Input(search_f_date, key='sbs_dtfrom')],
                   [sg.Text('Date Stop  (Y-M-D):' , size=(15, 1)), sg.Input(search_t_date, key='sbs_dtto')],
                   [sg.Text('Language:'           , size=(15, 1)), sg.Input('italian', key='dictionary')],
                   [sg.Text('Time Delta (d):'     , size=(15, 1)), sg.Input('10', size=(10, 1), key='sbs_t_delay'),
                    sg.Text('Co-Occurence Filter:', size=(15, 1)), sg.Input('5', size=(14, 1), key='co_occurence_filter')],
                   ]


        col_cloud = [
#                    [sg.Text('Brands (A;B;C...):'  , size=(15, 1)), sg.Input(sna,  key='cloud_brand')],
                     [sg.Text('Date Start (Y-M-D):' , size=(15, 1)), sg.Input(search_f_date, key='cloud_dtfrom')],
                     [sg.Text('Date Stop  (Y-M-D):' , size=(15, 1)), sg.Input(search_t_date, key='cloud_dtto')],
                     [sg.Text('Language:'           , size=(15, 1)), sg.Input('italian', key='cloud_dictionary')],
                     [sg.Text('Time Delta (d):'     , size=(15, 1)), sg.Input('10', size=(10, 1), key='cloud_t_delay')]
                     ]

        parent_execution = [[sg.Column(col_search)]
                            ]
        


        tab_execution =  [[sg.T('Search twitter messags')], 
                          [sg.Column(parent_execution)],
                          [sg.Button('Execute Scrap'), sg.Button('Resume Scrap')],
                          ]

        tab_config =  [[sg.T('Set Twitter API Config')], 
                       [sg.Column(col_execution)], 
                       [sg.Button('Update')]]

        tab_API =  [[sg.T('Get Twitter User Details')], 
                    [sg.Column(col_api)],
#                    [sg.Text('Folder Name'), sg.Input(key='p_folder'), sg.FolderBrowse()], 
                    [sg.Button('Execute API')]]

        tab_SBS =  [[sg.T('Generate Semantic Brand Score')], 
                    [sg.Column(col_sbs)],
#                    [sg.Text('Folder Name'), sg.Input(key='sbs_folder'), sg.FolderBrowse()], 
                    [sg.Button('Execute SBS'),sg.Button('Graph SBS'), sg.Button('Graph C-D-P'), sg.Button('Graph Word')]]

#        tab_cluster =  [[sg.T('Generate Clustered Plot')], 
#                    [sg.Column(col_cluster_plot)],
#                    [sg.Button('Execute Cluster')]]

        tab_CloudWord = [[sg.T('Generate Word Cloud/Sentiment/Network Graph From Messages')],
                         [sg.Column(col_cloud)],
                         [sg.Button('Compute Cloud'), sg.Button('Compute Sentiment'), sg.Button('Compute Net')]
                         ]

        layout = [[sg.TabGroup([[sg.Tab('Messages'    , tab_execution)],
                                [sg.Tab('User Profile', tab_API)],
                                [sg.Tab('Config'      , tab_config)],
                                [sg.Tab('SNA-SBS'     , tab_SBS)],
                                [sg.Tab('Graph Plot'  , tab_CloudWord)]
#                                [sg.Tab('Plot Cluster', tab_cluster)]
                                ])],
                  [sg.Text('Folder Name'), sg.Input(key='folder'),  sg.FolderBrowse()],
                  [sg.Button('Quit'), sg.T('      Master Data Science '+comment)]
                 ]

#        window = sg.Window('Get Deep Tweeter Search Messages - Powered By Ceryx@live.com - v2.0', layout)
        window = sg.Window('Get Deep Tweeter Search Messages - v2.3', layout)

##################################################################################################################################
#1.1 - Namage both file and satabase. 
#1.2 - In the restart if database does not exist, will create it empty and revert all of csv data inside
#1.3 - In the restart jumpp all of the messages already loaded in the database; discrininate by date from 
#1.4 - add new control for date from and date to. Now the programm get only the missing message in the date range
#1.5 - Add MSG_NO in the SBS table
#1.6 - Add read from table in the profile search
#1.7 - Add Co-Occurrence filtering for SNA computation
#1.8 - Add date to in SBS TAB control, add date control
#1.9 - Add Word Cloud graphic
#2.0 - Add Clustering graphic
#2.1 - add bug fix to computation range time at the end cycle sbs and cloud graph
#2.2 - Add network graph and sentiment analysis
#2.3 - Add network work association and fix minor bugs
        
        try:
            while(True):
                self.tweets_data = None
                event, values = window.Read()
                
                if event is not None and event in 'Quit':
#                    for key, val in values.items():
#                        print ('values['+str(key)+']', val)
                    self.cancel(window)
                    break
                elif event is not None and event in 'Execute Scrap':
                   ret = self.execute_sraping(values)
                   if ret == 1:
                       continue
                   ret = self.execute_scrap_retweet(values, False)
                   if ret == 1:
                       continue
                elif event is not None and event in 'Resume Scrap':
                   ret = self.execute_scrap_retweet(values, True)
                   if ret == 1:
                       continue
                elif event is not None and event in 'Update':
                    self.push_tag(values)
                    continue
                elif event is not None and event in 'Execute API':
                    ret = self.execute_api(values)
                    if ret == 1:
                        continue
                elif event is not None and event in 'Execute SBS':
                    print('Execute SBS')
                    ret = self.execute_sbs(values)
                    if ret == 1:
                        continue
                elif event is not None and event in 'Graph SBS':
                    print('Graph SNA')
                    ret = self.compute_sna(values)
                    if ret == 1:
                        continue
                elif event is not None and event in 'Graph C-D-P':
                    print('Graph C-D-P')
                    ret = self.compute_cluster(values)
                    if ret == 1:
                        continue
                elif event is not None and event in 'Compute Cloud':
                    print('Compute Cloud')
                    ret = self.elaborate_from_messages(values, 'C')
                    if ret == 1:
                        continue
                elif event is not None and event in 'Compute Sentiment':
                    print('Compute Sentiment')
                    ret = self.elaborate_from_messages(values, 'S')
                    if ret == 1:
                        continue
                elif event is not None and event in 'Compute Net':
                    print('Compute Sentiment')
                    ret = self.elaborate_from_messages(values, 'N')
                    if ret == 1:
                        continue
                elif event is not None and event in 'Graph Word':
                    print('Graph Word')
                    ret = self.compute_word_associate(values)
                    if ret == 1:
                        continue



                else:
                    window.Close()
                    break
        except Exception as e:
            print(e)
            sg.PopupError(e)
            window.Close()
            
    def cancel(self, window):
        print ('Event Cancel')
        window.Close()

    def execute_sraping(self, values):
        BASE_PATH = values['folder'].strip()
        query     = values['query'].lower()
        deep      = values['deep']
        dtfrom    = values['dtfrom'].strip()
        dtto      = values['dtto'].strip()
        
        if (not BASE_PATH):
            sg.PopupError('ERROR: Folder Path is empty')
            return 1
        else:
            BASE_PATH = BASE_PATH+'/'
        print('BASE_PATH:', BASE_PATH)
        file_query = regex.sub("_", query)
        path_file  = BASE_PATH+file_query+tws.EXT
        db_engine  = sqlite.db_sqlite(BASE_PATH+file_query+DB_ext)
        engine     = db_engine.get_db_file_connection()

        if (not deep or not deep.isdigit() or int(deep) == 0):
            sg.PopupError('ERROR: Deep must be numeric and non zero')
            return 1
        else:
            deep = int(deep)
        #print('query:', query, 'deep:', deep)

        try:
            if (query.strip()):
                if (dtfrom and dtto):
                    print('Execute by date')
                    try:
                        datetime.strptime(dtfrom, '%Y-%m-%d')
                    except Exception as e:
                        sg.PopupError('ERROR: date', dtfrom, e)
                        return 1
                    try:
                        datetime.strptime(dtto, '%Y-%m-%d')
                    except Exception as e:
                        sg.PopupError('ERROR: date', dtto, e)
                        return 1
                    s_client = tws.SeleniumClient(tws.BASE_URL)
                    tweets_data = s_client.search_date_tweets(query, dtto, dtfrom, deep)
                    if (tweets_data is not None):
                        tweets_df = pd.DataFrame(tweets_data)
#                        tweets_df.to_sql('tw_messages', con=engine, if_exists='append')
                        tweets_df.to_sql(tw_message, con=engine, if_exists='append')

                        engine.close()
                        tweets_df.to_csv(path_file, sep='|', encoding = "UTF-8", header=True, index=False)
                    else:
                        sg.PopupError('ERROR: Dataframe Empty')
                        return 1
                    return 0
                elif (not dtfrom and dtto):
                    print('Date From Empty, both date must be filled')
                    sg.PopupError('Date From Empty, both date must be filled')
                    return 1
                elif (dtfrom and not dtto):
                    print('Date To Empty, both date must be filled')
                    sg.PopupError('Date From Empty, both date must be filled')
                    return 1
                else:
                    print('Execute search')
                    s_client = tws.SeleniumClient(tws.BASE_URL)
                    tweets_data = s_client.search_tweets(query, deep)
                    if (tweets_data is not None):
                        tweets_df = pd.DataFrame(tweets_data)
                        tweets_df.to_sql(tw_message, con=engine, if_exists='append')
                        engine.close()
                        tweets_df.to_csv(path_file, sep='|', encoding = "UTF-8", header=True, index=False)
                    else:
                        sg.PopupError('ERROR: Dataframe Empty')
                        return 1
                    return 0
            else:
                print('Search Is Empty!!')
                sg.PopupError('ERROR: Search cannot be empty')
                return 1
        except Exception as ee:
            print('execute_sraping',ee)
            engine.close()
            return 1
        
    def execute_scrap_retweet(self, values, is_resume):    
        query     = values['query'].lower()
        BASE_PATH = values['folder'].strip()
        date_from = values['dtfrom'].strip()
        date_to   = values['dtto'].strip()
        
#        try:
#            if (date_from):
#                datetime.strptime(date_from, '%Y-%m-%d')
#        except Exception as e:
#            sg.PopupError('ERROR: date',date_from, e)
#            return 1
#
#        try:
#            if (date_to):
#                datetime.strptime(date_to, '%Y-%m-%d')
#        except Exception as e:
#            sg.PopupError('ERROR: date',date_to, e)
#            return 1

        if (not BASE_PATH):
            sg.PopupError('ERROR: Folder Path is empty')
            return 1
        else:
            BASE_PATH = BASE_PATH+'/'
        print('BASE_PATH:', BASE_PATH)
        file_query = regex.sub("_", query)
        path_file = BASE_PATH+file_query+tws.EXT

        db_engine  = sqlite.db_sqlite(BASE_PATH+file_query+DB_ext)
        engine = db_engine.get_db_file_connection()

        try:
            sql = ' select "user_id", "re_tweet_no", "re_tweet_uri" ,"date" from "%s";' % (tw_message)
            df  = pd.read_sql_query(sql, con=engine)
            exist = len(df.user_id)
            print('exist',exist)
        except Exception as e:
            print('WARNING: execute_scrap_retweet', e)
            exist = 0

        if (os.path.isfile(path_file) and exist == 0):
            df = pd.read_csv(path_file, sep='|', encoding = "UTF-8")
            print('path_file:', path_file)
            df.to_sql(self.tw_message, con=engine, if_exists='replace')
            exist = 1
        
#        if(exist == 0):
#            sg.PopupError('ERROR: File not exist:', path_file)
#            return 1

        tweets_no   = df.re_tweet_no
        tweets_uri  = df.re_tweet_uri
        tweets_user = df.user_id
        tweets_date = df.date
        
        try:
            threads = []
            for idx in range(len(tweets_no)):
                tweet_no   = tweets_no[idx]
                tweet_uri  = tweets_uri[idx]
                tweet_user = regex.sub('',str(tweets_user[idx]))
                tweet_date = tweets_date[idx].split()[0]
                rt_query = file_query+'-'+tweet_user
                if tweet_date < date_from or tweet_date > date_to:
                    print('continue',tweet_date , date_from, date_to)
                    continue
                print('execute',tweet_date , date_from, date_to)
                    
                path_re_file = BASE_PATH+rt_query+tws.EXT
                if is_resume:
                    if os.path.isfile(path_re_file):
                        print('already exist:', path_re_file)
                        continue
                    else:
                        sql = ' select count("user_id") as user from "%s" where "user_id"="%s" and date ="%s";' % (rtw_message, tweet_user, tweet_date)
                        print(sql)
                        users = 0
                        try:
                            df  = pd.read_sql_query(sql, con=engine)
                            users = df.user
                            print('users:',users[0])
                        except Exception as e:
                            users = 0
                        if users[0] > 0:
                            continue
                
#                print('start threads...')
                t= threading.Thread(target=self.th_execute_scrap_retweet,args=(engine,
                                                                               query, 
                                                                               BASE_PATH, 
                                                                               rt_query, 
                                                                               tweet_no, 
                                                                               tweet_uri 
                                                                               ))
                threads.append(t)
                t.setDaemon(True)
                t.start()
#                print('start thread',tweet_uri)
                time.sleep(3)
                if (len(threads) > 4):
                    flag =1
                    while (flag):
#                        print('cycle true')
                        for thread in range(len(threads)):
#                            print('th_queue:', len(threads), 'thread:',thread)
                            if (threads[thread].isAlive()):
                                time.sleep(1)
#                                print('thread:',thread, 'stil alive')
                            else:
                                try:
                                    del threads[thread]
#                                    print('thread:',thread, 'finish, remove it...')
                                except Exception as thr:
                                    print(thr)
                                    print('thread:',thread, 'already removed')
                                break
                        if (len(threads) < 4):
                            flag=0

#            waiting all thread is ending before to close the connection
            while(len(threads) >0):
                if (not threads[0].isAlive()):
                    del threads[0]
                time.sleep(1)
            engine.close()
        except Exception as e:
            print ('execute_scrap_retweet', e)
            engine.close()
            return 1

    def th_execute_scrap_retweet(self, engine, query, BASE_PATH, file_query, tweet_no, tweet_uri):
#        print('th_execute, tweet_no:',tweet_no)
        if (tweet_no is not None and int(tweet_no) >0 ):
            s_client = tws.SeleniumClient(tws.BASE_URL)
            tweets_data = s_client.url_tweets(tweet_uri, int(tweet_no))
            if (tweets_data is not None):
                tweets_df = pd.DataFrame(tweets_data)
                path_re_file = BASE_PATH+file_query+tws.EXT
                sequence=0
                while (os.path.isfile(path_re_file)):
                    sequence +=1
                    path_re_file = BASE_PATH+file_query+'_'+str(sequence)+tws.EXT
                tweets_df.to_csv(path_re_file, sep='|', header=True, index=False)
            try:
                tweets_df.to_sql(self.rtw_message, con=engine, if_exists='append')
            except Exception as sqle:
                print('th_execute_scrap_retweet', sqle)
        

    def push_tag(self, values):
        print('push tag') 
        
        self.ACCESS_TOKEN    = values['a_token']
        self.ACCESS_SECRET   = values['a_secret']
        self.CONSUMER_KEY    = values['c_key']
        self.CONSUMER_SECRET = values['c_secret']
        
        tot = len(self.ACCESS_TOKEN)+len(self.ACCESS_SECRET)+len(self.CONSUMER_KEY)+len(self.CONSUMER_SECRET)
        if (tot == 0):
            sg.PopupError('ERROR: Missing Twitter Apy key')

    def execute_api(self, values):

        BASE_PATH = values['folder'].strip()
        if (not BASE_PATH):
            sg.PopupError('ERROR: Folder Path is empty')
            return 1
        else:
            BASE_PATH = BASE_PATH+'/'
        print('BASE_PATH:', BASE_PATH)

        tw_prof = tw_api.Twitter_API(acc_token=ACCESS_TOKEN, 
                           acc_secret=ACCESS_SECRET, 
                           cons_token=CONSUMER_KEY, 
                           cons_secret=CONSUMER_SECRET)
        tw_prof.get_twitter_connection()

        if(values['p_radio1']):
            print('Search profile by DB then by file') 

            l_files = [os.path.join(root, name)
                      for root, dirs, files in os.walk(BASE_PATH)
                      for name in files
                      if name.endswith((DB_ext))]
    
            l_user_id=[]
            print('Search the users...')
            for path_db in l_files:
                db_engine  = sqlite.db_sqlite(path_db)
                engine     = db_engine.get_db_file_connection()
                no_of_message  = 0
                for table in tables:
                    try:
                        sql = ' select distinct("user_id") from "%s" ;' % (table)
                        ret_sql    = pd.read_sql_query(sql, con=engine)
                        ret_sql = ret_sql.user_id
                        no_of_message = len(ret_sql)
                    except Exception as e:
                            print(e)
                            no_of_message = 0

                    if (no_of_message > 0):
                        l_user_id.extend(ret_sql)

                l_user_id = list(set(l_user_id))
                print('DB', path_db, 'User id:', len(l_user_id))
                if (len(l_user_id) > 0):
                    print('l_users, call tw_search_profile')
                    result = tw_prof.tw_search_profile(screen_name=None, user_id=l_user_id)
                    if (result is not None):
                        tweets_df = pd.DataFrame(result)
                        try:
                            tweets_df.to_sql('tw_profiles', con=engine, if_exists='append')
                        except Exception as sqle:
                            print('sqle - execute_sbs', sqle)
                engine.close()
    
            if (len(l_user_id) < 1):
    
                l_files = os.listdir(BASE_PATH)
                for file in l_files:
                    if ('profiles' in file):
                        continue
                    path_file = BASE_PATH+file
                    print('path_file:',path_file)
                    if (not path_file.endswith('csv') ):
                        print('WARNIN: File wrong format:', path_file)
                        continue
                    df = pd.read_csv(path_file, sep='|', encoding = "UTF-8")
                    l_user_id.extend(df.user_id)
                    l_user_id = list(set(l_user_id))
    
                l_user_id = list(set(l_user_id))
                print('Total Users:', len(l_user_id))
                
                if (len(l_user_id) > 0):
                    print('l_users, call tw_search_profile')
                    result = tw_prof.tw_search_profile(screen_name=None, user_id=l_user_id)
                    if (result is not None):
                        tweets_df = pd.DataFrame(result)
                        tweets_df.to_csv(BASE_PATH+'profiles.csv', sep='|', encoding = "UTF-8", header=True, index=False)
                 
                return 0
        elif(values['p_radio2']): # search by file
            print('Search profile by user name') 

            l_users = [values['p_name'].strip()]
            if (len(l_users) > 0):
                ## veroificare perche' non trova i nomi sotto forma di lista
                print(l_users)
                result = tw_prof.tw_search_profile(screen_name=None, user_id=l_users)
                if result is not None:
                    tweets_df = pd.DataFrame(result)
                    tweets_df.to_csv(BASE_PATH+'profiles.csv', sep='|', encoding = "UTF-8", header=True, index=False)
            else:
                sg.PopupError('ERROR: write user for profile')
                return 1
            return 0

        
    def execute_api_msg(self, values):
        print('Aearch twitter msg by API query')
        BASE_PATH = values['folder'].strip()
        if (not BASE_PATH):
            sg.PopupError('ERROR: Folder Path is empty')
            return 1
        else:
            BASE_PATH = BASE_PATH+'/'
        print('BASE_PATH:', BASE_PATH)

        user_profile = values['p_name'].strip()
        print('user_profile', user_profile)
        # TODO finish this part....
        return 0

    def execute_sbs(self, values):
        print('Execute SBS')
#        query         = values['query'].lower()
        BASE_PATH     = values['folder'].strip()
        l_brand       = values['brands'].strip()
        language      = values['dictionary'].strip()
        sbs_dtfrom    = values['sbs_dtfrom'].strip()
        sbs_dtto      = values['sbs_dtto'].strip()
        sbs_t_delay   = values['sbs_t_delay'].strip()
        co_occ_filter = values['co_occurence_filter'].strip()

#        file_query = regex.sub("_", query)

        if (not sbs_t_delay):
            sg.PopupError('ERROR: Time delay cannot be empty')
            return 1
        else:
            sbs_t_delay = int(sbs_t_delay)

        if (not co_occ_filter):
            sg.PopupError('ERROR: Co-Occurrence cannot be empty')
            return 1
        else:
            co_occ_filter = int(co_occ_filter)

        if (not BASE_PATH):
            sg.PopupError('ERROR: Folder Path is empty')
            return 1
        else:
            BASE_PATH = BASE_PATH+'/'
        print('BASE_PATH:', BASE_PATH)

        if (not l_brand):
            sg.PopupError('ERROR: Brand(s) is mandatory')
            return 1
        l_brand = l_brand.split(';')
        brands=[]
        for brand in l_brand:
            if (brand):
                brands.append(brand)   
        sbs_engine = sbs.SBS()
        try:
            l_files   = os.listdir(BASE_PATH)
#            print('l_files',l_files)
            try:
                dt_from  = datetime.strptime(sbs_dtfrom, '%Y-%m-%d')
            except Exception as e:
                sg.PopupError('ERROR: date',sbs_dtfrom, e)
                return 1
                
            try:
                sbs_dtto = datetime.strptime(sbs_dtto, '%Y-%m-%d')
            except Exception as e:
                sg.PopupError('ERROR: date',sbs_dtto, e)
                return 1
            dt_to = dt_from + timedelta(days=sbs_t_delay)
            flag = True
#            tables=[rtw_message,tw_message]
            while(flag):
                total_sql=[]
                for file in l_files:
                    if (self.DB_ext in file and 'SBS' not in file):
                        print('file:', file)
                        db_engine  = sqlite.db_sqlite(os.path.join(BASE_PATH, file))
                        engine     = db_engine.get_db_file_connection()
                        no_of_message  = 0
                        no_of_message2 = 0

                        if (dt_to > sbs_dtto):
                            print(dt_to, '>', sbs_dtto)
                            dt_to = sbs_dtto

                        for table in tables:
                            sql = ' select "message" from "%s" where "date" BETWEEN \'%s\' AND \'%s\';' % (table, dt_from, dt_to)
#                            print(sql)
                            try:
                                ret_sql    = pd.read_sql_query(sql, con=engine)
                                ret_sql = ret_sql.message
                                no_of_message2 = len(ret_sql)
                                no_of_message += no_of_message2
                            except Exception as no_sql:
                                print(file, no_sql)
                                no_of_message2 = 0
                            
                            if (no_of_message2 > 0):
                                total_sql.extend(ret_sql)
                        print('- ', file, 'tweet->', (no_of_message-no_of_message2), 'retweet->', no_of_message2, 'Date to->', dt_to)
                        engine.close()


                if (len(total_sql) > 0):
                    SBS = sbs_engine.compute_sbs(total_sql, brands, language, dt_to, co_occ_filter)
                    SBS.to_csv(BASE_PATH+'SBS.csv', sep='|', encoding = "UTF-8", header=True, index=False)
                    try:
                        db_engine  = sqlite.db_sqlite(BASE_PATH+'SBS'+DB_ext)
                        engine     = db_engine.get_db_file_connection()
                        SBS.to_sql('sbs', con=engine, if_exists='append')
                        engine.close()
                    except Exception as ex:
                        print('ex - execute_sbs - save sbs result', ex)
                else:
                    print('SBS - No data available')

                if (str(dt_to) in str(sbs_dtto)):
                    flag = False

                dt_from = dt_from + timedelta(days=int(sbs_t_delay))
                dt_to   = dt_to  + timedelta(days=int(sbs_t_delay))

        except Exception as sqle:
            print('Error on sql-execute_sbs', sqle)
#            SBS = None
            if (engine):
                engine.close()
        return 0

    def compute_sna(self, values):
        print('Compute SNA')
        BASE_PATH   = values['folder'].strip()
        sbs_dtfrom  = values['sbs_dtfrom'].strip()
        sbs_dtto    = values['sbs_dtto'].strip()
        try:
            datetime.strptime(sbs_dtfrom, '%Y-%m-%d')
        except Exception as e:
            sg.PopupError('ERROR: date',sbs_dtfrom, e)
            return 1
        try:
            datetime.strptime(sbs_dtto, '%Y-%m-%d')
        except Exception as e:
            sg.PopupError('ERROR: date',sbs_dtto, e)
            return 1

        if (not BASE_PATH):
            sg.PopupError('ERROR: Folder Path is empty')
            return 1
        else:
            BASE_PATH = BASE_PATH+'/'
        print('BASE_PATH:', BASE_PATH)

        table='sbs'
        PLOTTER={}
        statistic={}
        try:
            db_engine = sqlite.db_sqlite(BASE_PATH+'SBS'+DB_ext)
            engine    = db_engine.get_db_file_connection()
            sql       = 'select distinct (BRAND) from %s;' % (table)
            brands   = pd.read_sql_query(sql, con=engine)
            brands = brands.BRAND
            for brand in brands:
                sql = 'select SBS, DATE, MSG_NO from "%s" where "DATE" BETWEEN \'%s\' AND \'%s\' and BRAND=\'%s\';' % (table, sbs_dtfrom, sbs_dtto, brand)
                ret_sql    = pd.read_sql_query(sql, con=engine)
                y_sbs = ret_sql.SBS
                n_msg = ret_sql.MSG_NO
                x_date = [date.split(' ')[0][5:] for date in ret_sql.DATE]
                PLOTTER[brand] = [x_date, y_sbs, n_msg]
            engine.close()
        except Exception as sqle:
            print('Error on sql-execute_sbs', sqle)
            if (engine):
                engine.close()
        draw = splot.graphic(BASE_PATH)
        draw.sna_ts(PLOTTER, brands)
        return 0

    def compute_cluster(self, values):
        print('Compute SNA')
        BASE_PATH   = values['folder'].strip()

        if (not BASE_PATH):
            sg.PopupError('ERROR: Folder Path is empty')
            return 1
        else:
            BASE_PATH = BASE_PATH+'/'
        print('BASE_PATH:', BASE_PATH)

        table='sbs'
        cluster_plot = pltc.plot_clustered()
        try:
            db_engine = sqlite.db_sqlite(BASE_PATH+'SBS.db')
            engine    = db_engine.get_db_file_connection()
            sql       = 'SELECT distinct (DATE) FROM %s;' % (table)
            dates   = pd.read_sql_query(sql, con=engine)
            dates   = dates.DATE
            for date in dates:
                sql = 'select BRAND, PREVALENCE, DIVERSITY, CONNECTIVITY from "%s" where "DATE" ="%s";' % (table, date)
                df_ret = pd.read_sql_query(sql, con=engine)
                df_ret = df_ret.set_index('BRAND')
                date = date.split(' ')[0]
                print(date)
#                print(df_ret)
                figure, extent = cluster_plot.plot_clustered_stacked([df_ret],[date], date)
                figure.show()
                figure.savefig(BASE_PATH+date+'.png', bbox_inches=extent.expanded(1.7, 1.5))
                
            engine.close()
        except Exception as sqle:
            print('Error on sql-execute_sbs', sqle)
            if (engine):
                engine.close()
        return 0

    def elaborate_from_messages(self, values, type_oper):
        #Controllo delle varibili
        print('Compute Cloud')
#        query         = values['query'].lower()
        BASE_PATH     = values['folder'].strip()
#        cloud_brand       = values['cloud_brand'].strip()
        cloud_language    = values['cloud_dictionary'].strip()
        cloud_dtfrom    = values['cloud_dtfrom'].strip()
        cloud_dtto      = values['cloud_dtto'].strip()
        cloud_t_delay   = values['cloud_t_delay'].strip()
#        cloud_co_occ_filter = values['cloud_co_occurence_filter'].strip()

#        file_query = regex.sub("_", query)

        if (not cloud_t_delay):
            sg.PopupError('ERROR: Time delay cannot be empty')
            return 1
        else:
            cloud_t_delay = int(cloud_t_delay)

#        if (not cloud_co_occ_filter):
#            sg.PopupError('ERROR: Co-Occurrence cannot be empty')
#            return 1
#        else:
#            cloud_co_occ_filter = int(cloud_co_occ_filter)

        if (not BASE_PATH):
            sg.PopupError('ERROR: Folder Path is empty')
            return 1
        else:
            BASE_PATH = BASE_PATH+'/'
        print('BASE_PATH:', BASE_PATH)

#        if (not cloud_brand):
#            sg.PopupError('ERROR: Brand(s) is mandatory')
#            return 1
#        cloud_brand = cloud_brand.split(';')
#        brands=[]
#        for brand in cloud_brand:
#            if (brand):
#                brands.append(brand) 
        
        if 'C' == type_oper:
            generate = wcl.word_cloud()
        elif 'S' == type_oper:
            generate = stmtb.sentiment_brand()
        elif 'N' == type_oper:
            generate = ntwk.network_brand()
        else:
            sg.PopupError('ERROR: Wrong parameter type')
            return 1

        #Read messages by date
        try:
            l_files   = os.listdir(BASE_PATH)
            print('l_files',l_files)
            try:
                dt_from  = datetime.strptime(cloud_dtfrom, '%Y-%m-%d')
            except Exception as e:
                sg.PopupError('ERROR: date',cloud_dtfrom, e)
                return 1
                
            try:
                cloud_dtto = datetime.strptime(cloud_dtto, '%Y-%m-%d')
            except Exception as e:
                sg.PopupError('ERROR: date',cloud_dtto, e)
                return 1
            
            dt_to = dt_from + timedelta(days=cloud_t_delay)

            flag = True
#            tables=[rtw_message, tw_message]
            while(flag):
                for file in l_files:
                    total_sql=[]
#                    print('file:', file, self.DB_ext)
                    if (self.DB_ext in file and 'SBS' not in file):
#                        print('file:', file)
                        db_engine  = sqlite.db_sqlite(os.path.join(BASE_PATH, file))
                        engine     = db_engine.get_db_file_connection()
                        no_of_message  = 0
                        no_of_message2 = 0

                        if (dt_to > cloud_dtto):
                            print(dt_to, '>', cloud_dtto)
                            dt_to = cloud_dtto

                        for table in tables:
                            sql = ' select "message" from "%s" where "date" BETWEEN \'%s\' AND \'%s\';' % (table, dt_from, dt_to)
#                            print(sql)
                            try:
                                ret_sql = pd.read_sql_query(sql, con=engine)
                                ret_sql = ret_sql.message
                                no_of_message2 = len(ret_sql)
                                no_of_message += no_of_message2
                            except Exception as no_sql:
                                print(file, no_sql)
                                no_of_message2=0
                                
                            if (no_of_message2 > 0):
                                total_sql.extend(ret_sql)
                        print('- ', file, 'tweet->', (no_of_message-no_of_message2), 'retweet->', no_of_message2, 'Date to->', dt_to)
                        engine.close()
                    else:
                        continue
                    
                    if (len(total_sql) > 0):
                        _dateTo = str(dt_to).split(' ')[0]
                        _dateFrom = str(dt_from).split(' ')[0]
                        fileName = file.replace('.db', '')+'_'+ _dateFrom + '_' + _dateTo
                        brand_name = file.replace('.db', '')
                        file_gfx = fileName + '.gefx'
                        print('1')
                        if 'C' == type_oper:
                            data = ' '.join(total_sql)
                            file_img = fileName+ '_C.png'
                            brand_name = fileName
                            print('cloud')
                        elif 'S' == type_oper:
                            data = [' '.join(total_sql)]
                            file_img = fileName + '_S.png'
                            print('sentiment')
                        else:
                            data = total_sql
                            file_img = fileName + '_N.png'
                            print('network')
                            
#                        print('Sample:', data[0:10])
#                        wcl_engine.show_wordcloud(BASE_PATH, cloudImage, data, cloud_language, fileName, 200, 40)
                        time.sleep(1)
                        print('3')
                        generate.process_messages(path=BASE_PATH, file_img=file_img, 
                                                  file_gfx=file_gfx, data_msg=data, 
                                                  dictionary=cloud_language, title=brand_name, 
                                                  max_words=200, max_font_size=40)
                    else:
                        print('Not enough message to process...')

                if (str(dt_to) in str(cloud_dtto)):
                    flag = False
                dt_from = dt_from + timedelta(days=int(cloud_t_delay))
                dt_to   = dt_to  + timedelta(days=int(cloud_t_delay))

            if 'S' == type_oper:
                generate.sentiment_draw(BASE_PATH)

        except Exception as sqle:
            print('Error on elaborate_from_messages', sqle)
            if (engine):
                engine.close()
        return 0


    def compute_word_associate(self, values):
        print('compute word associate')
#        query         = values['query'].lower()
        BASE_PATH     = values['folder'].strip()
        l_brand       = values['brands'].strip()
        language      = values['dictionary'].strip()
        sbs_dtfrom    = values['sbs_dtfrom'].strip()
        sbs_dtto      = values['sbs_dtto'].strip()
        sbs_t_delay   = values['sbs_t_delay'].strip()
        co_occ_filter = values['co_occurence_filter'].strip()

#        file_query = regex.sub("_", query)

        if (not sbs_t_delay):
            sg.PopupError('ERROR: Time delay cannot be empty')
            return 1
        else:
            sbs_t_delay = int(sbs_t_delay)

        if (not co_occ_filter):
            sg.PopupError('ERROR: Co-Occurrence cannot be empty')
            return 1
        else:
            co_occ_filter = int(co_occ_filter)

        if (not BASE_PATH):
            sg.PopupError('ERROR: Folder Path is empty')
            return 1
        else:
            BASE_PATH = BASE_PATH+'/'
        print('BASE_PATH:', BASE_PATH)

        if (not l_brand):
            sg.PopupError('ERROR: Brand(s) is mandatory')
            return 1
        l_brand = l_brand.split(';')
        brands=[]
        for brand in l_brand:
            if brand:
                brands.append(brand)   
        try:
            l_files   = os.listdir(BASE_PATH)
#            print('l_files',l_files)
            try:
                dt_from  = datetime.strptime(sbs_dtfrom, '%Y-%m-%d')
            except Exception as e:
                sg.PopupError('ERROR: date',sbs_dtfrom, e)
                return 1
                
            try:
                sbs_dtto = datetime.strptime(sbs_dtto, '%Y-%m-%d')
            except Exception as e:
                sg.PopupError('ERROR: date',sbs_dtto, e)
                return 1
            dt_to = dt_from + timedelta(days=sbs_t_delay)
            flag = True
#            tables=[rtw_message,tw_message]
            while(flag):
                total_sql=[]
                for file in l_files:
                    if (self.DB_ext in file and 'SBS' not in file):
                        print('file:', file)
                        db_engine  = sqlite.db_sqlite(os.path.join(BASE_PATH, file))
                        engine     = db_engine.get_db_file_connection()
                        no_of_message  = 0
                        no_of_message2 = 0

                        if (dt_to > sbs_dtto):
                            print(dt_to, '>', sbs_dtto)
                            dt_to = sbs_dtto

                        for table in tables:
                            sql = ' select "message" from "%s" where "date" BETWEEN \'%s\' AND \'%s\';' % (table, dt_from, dt_to)
#                            print(sql)
                            try:
                                ret_sql    = pd.read_sql_query(sql, con=engine)
                                ret_sql = ret_sql.message
                                no_of_message2 = len(ret_sql)
                                no_of_message += no_of_message2
                            except Exception as no_sql:
                                print(file, no_sql)
                                no_of_message2 = 0
                            
                            if (no_of_message2 > 0):
                                total_sql.extend(ret_sql)
                        print('- ', file, 'tweet->', (no_of_message-no_of_message2), 'retweet->', no_of_message2, 'Date to->', dt_to)
                        engine.close()


                if (len(total_sql) > 0):
                    word_a = word_ass.word_association()
                    word_a.process_messages(path=BASE_PATH, dt=str(dt_to).split(' ')[0], 
                                            data_msg=total_sql, dictionary=language, 
                                            title=brands, co_occurrence=co_occ_filter)
#                    try:
#                        db_engine  = sqlite.db_sqlite(BASE_PATH+'SBS'+DB_ext)
#                        engine     = db_engine.get_db_file_connection()
#                        SBS.to_sql('sbs', con=engine, if_exists='append')
#                        engine.close()
#                    except Exception as ex:
#                        print('ex - execute_sbs - save sbs result', ex)
                else:
                    print('SBS - No data available')

                if (str(dt_to) in str(sbs_dtto)):
                    flag = False

                dt_from = dt_from + timedelta(days=int(sbs_t_delay))
                dt_to   = dt_to  + timedelta(days=int(sbs_t_delay))

        except Exception as sqle:
            print('Error on sql-execute_sbs', sqle)
#            SBS = None
            if (engine):
                engine.close()
        return 0



###########################################################################################

#sg.Popup(event, values, line_width=200)
generate = Graphic_interface()
generate.start_it()




