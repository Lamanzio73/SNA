from wordcloud import WordCloud, STOPWORDS
import matplotlib.pyplot as plt
stopwords = set(STOPWORDS)
import csv
import nltk
import re
import string
#wordcloud.to_file("img/first_review.png")

class word_cloud(object):
    def __init__(self):
        print('Init word cloud')

    def process_messages(self, path=None, file_img=None, file_gfx=None, data_msg=None, dictionary=None, title=None, max_words=None, max_font_size=None):
#        nltk.download('stopwords')
        stopwords = nltk.corpus.stopwords.words(dictionary)

        regex = re.compile('[%s]' % re.escape(string.punctuation+'،‘"؛\''))
        pattern = re.compile(r'\b(' + r'|'.join(stopwords) + r')\b\s*')
        data_msg = regex.sub(' ', data_msg).lower()
        data_msg = re.sub(r'\b\w{1}\b', ' ', data_msg)
        data_msg = pattern.sub(' ', data_msg)
        data_msg = re.sub(' +',' ',data_msg)
        data_msg = data_msg.strip()
        
        if (len(data_msg)>0):
            wordcloud = WordCloud(
                background_color='white',
                max_words=max_words,
                max_font_size=max_font_size, 
                scale=3,
                random_state=2 # chosen at random by flipping a coin; it was heads
            ).generate(data_msg)
            plt.figure(1, figsize=[10,8])
            plt.imshow(wordcloud, interpolation="bilinear")
            plt.title(title,fontsize=20)
            plt.axis("off")
            plt.savefig(path+file_img, format="png")
            plt.show()
            plt.close('all')

        else:
            print('No data enough after stop word ')
    
    
    def prepare_file(self, path='D:/temp/SNA_temp/', file='salvini.csv'):
        readfile = csv.reader(open(path+file , 'rt',  encoding="utf-8"), delimiter = "|", quoting=csv.QUOTE_NONE)
        corpus =  []
        for line in readfile:
            corpus.append(line[6])
        corpus =  ' '.join(corpus)
        return corpus


######################################################################################################
#path='D:/temp/SNA_temp/'
#file='salvini.csv'
#corpus = prepare_file(path, file)
#file='salvini.png'
#show_wordcloud(path, file, corpus, 'italian', 'Salvini', 200, 40)



