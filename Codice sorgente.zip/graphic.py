#!/usr/bin/env python
# coding: utf-8

import matplotlib.pyplot as plt

BASE_PATH = ''
file_png  = 'SBS.png'



class graphic(object):
    colors = ['red', 'blue', 'green', 'yellow', 'purple']

    def __init__(self, BASE_PATH):
        print('Init Plotter')
        self.BASE_PATH=BASE_PATH
        self.file_png = file_png

    def sna_ts(self, PLOTTER, brands):
        plt.figure(num=None, figsize=(14, 10), dpi=120, facecolor='w', edgecolor='k')
        index = 0
        for brand in brands:
            xy_sbs = PLOTTER[brand]
#            plt.plot(xy_sbs[0], xy_sbs[1], marker = "o", color = self.colors[index], label=brand+' ('+str(xy_sbs[2])+')')
            plt.plot(xy_sbs[0], xy_sbs[1], marker = "o", color = self.colors[index], label=brand)
            index +=1
            if (index > len(brands)):
                index=0
            
        plt.legend()
        plt.title("Semantic Brand Score")
        plt.xlabel("Date 2019") 
        plt.ylabel("SBS")
        plt.savefig(self.BASE_PATH+file_png, transparent=False)
#        plt.show()
        plt.close('all')
#        print('Save to:',self.BASE_PATH+file_png)
        return













#path = 'C:\\Basket\\temp\\SNA2\\SBS.db'
#gr = graphic(path)
#gr.draw_sna_ts()




