# -*- coding: utf-8 -*-

import re
from datetime import datetime
import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys


#========================================= Static ==============================================================
#https://twitter.com/search?q=Salvini%20until%3A2019-04-21%20since%3A2019-04-01&src=typed_query
BASE_PATH = 'C:/Basket/RM/Python/SNA/output/'
EXT = '.csv'
BASE_URL      = 'https://twitter.com'
SEARCH_QUERY  = '/search?q='
SEARCH_TO     = '%20until%3A'
SEARCH_FROM   = '%20since%3A'
SRC           = '&src=typed_query'
regex = re.compile(r'[ #@!"£$%&?*+èéç°§ù]')


class SeleniumClient(object):
    def __init__(self, tw_url):
        #Initialization method. 
        # you need to provide the path of chromdriver in your system
        self.browser = webdriver.Firefox()
        self.base_url = tw_url
        self.search_url=''

    def search_date_tweets(self, query, search_t_date, search_f_date, deep):
        self.search_url = self.base_url+SEARCH_QUERY+query+SEARCH_TO+\
                        search_t_date+SEARCH_FROM+search_f_date+SRC
        print('Twitter Url search:',self.search_url)
        return self.get_tweets(deep)

    def search_tweets(self, query, deep):
        self.search_url = self.base_url+SEARCH_QUERY+query+SRC
        print('Twitter Url search:',self.search_url)
        return self.get_tweets(deep)

    def url_tweets(self, query, deep):
        self.search_url = self.base_url+query
        print('Twitter Url search:',self.search_url)
        return self.get_tweets(deep)

    def get_tweets(self, deep):
        ''' 
        Function to fetch tweets. 
        '''
        try: 
            self.browser.get(self.search_url)
            time.sleep(2)

            body = self.browser.find_element_by_tag_name('body')
            
            try: 
                cookie = self.browser.find_element_by_class_name("close")
                if (cookie is not None):
                    cookie.click()
                webdriver.ActionChains(self.browser).send_keys(Keys.ESCAPE).perform()
                #self.browser.switchTo().active_element
            except Exception as e:
                print("WARNING: "+ str(e))

            count_tweet = 0
            max_reiter = int(deep/4) + 5

            reiter = 0
            for _ in range(deep):
                body.send_keys(Keys.PAGE_DOWN)
                time.sleep(1)
                #print('Count:',_)
                #timeline = self.browser.find_element_by_id('timeline')
                tweet_nodes = self.browser.find_elements_by_css_selector('.tweet')
                # try to understant if the end page has been reached. 
                n_tweet = len(tweet_nodes)
                print('Tweet: Deep=', deep, 'Cycle=', _, 'Found=', n_tweet, 'Reiter=', reiter, 'of', max_reiter)
                if (n_tweet > count_tweet):
                    count_tweet = n_tweet
                    reiter = 0
                else:
                    reiter +=1
                if (reiter > max_reiter):
                    break
                

# =============================================================================
#            timeline = self.browser.find_element_by_id('timeline')
#            tweet_nodes = timeline.find_elements_by_css_selector('.tweet-text')
#            print([tweet_node for tweet_node in tweet_nodes])
#            return pd.DataFrame({'tweets': [tweet_node.text for tweet_node in tweet_nodes]})
#            report_df = pd.DataFrame()
#            timeline = self.browser.find_element_by_id('timeline')
#            tweet_nodes = timeline.find_elements_by_css_selector('.stream')
#            print('Number of tweet total: ', len(tweet_nodes))
# =============================================================================
            
            regex = re.compile(r'[\n\r\t]')
            data = {'date':[], 'name':[], 'screen_name':[],'user_id':[], 're_tweet_no':[], 're_tweet_uri':[], 'message':[]} 
            total_tweet=0
            for tweet_node in tweet_nodes:
                # tweet_node prendere da attribure tutti i campi
#                user_names  = tweet_node.find_elements_by_css_selector('.fullname')

                user_name         = tweet_node.get_attribute("data-name")
                user_scree_name   = tweet_node.get_attribute("data-screen-name")
                user_id           = tweet_node.get_attribute("data-user-id")


#                user_ids        = tweet_node.find_elements_by_css_selector('.username')
                tweet_texts = tweet_node.find_elements_by_css_selector('.tweet-text')
                times       = tweet_node.find_elements_by_css_selector('._timestamp')
                re_tweets   = tweet_node.find_elements_by_css_selector('.ProfileTweet-actionCountForPresentation')
                tweet_uri   = tweet_node.get_attribute("data-permalink-path")
                
#                user_name  = user_names[0].text
#                user_id    = user_ids[0].text
                tweet_text = tweet_texts[0].text
                timestamp  = times[0].get_attribute("data-time")
                dt_object  = datetime.fromtimestamp(int(timestamp))

                if (len(re_tweets) > 0 and re_tweets[0].text != ''):
                    re_tweet = re_tweets[0].text
                else:
                    re_tweet = '0'
                total_tweet +=int(re_tweet)

                data['date'].append(str(dt_object).strip())
                data['name'].append(regex.sub(" ", user_name.strip()))
                data['screen_name'].append(regex.sub(" ", user_scree_name.strip()))
                data['user_id'].append(regex.sub(" ", user_id.strip()))
                data['re_tweet_no'].append(re_tweet.strip())
                data['re_tweet_uri'].append(tweet_uri)
                data['message'].append(regex.sub(" ", tweet_text.strip()))
            
            self.browser.close()
            print('re_tweet', total_tweet)
            return data
        except Exception as e:
            print("get_tweets - An error occured while fetching tweets.", e)
            return None
#========================================= Main ==============================================================
#        def sel_path(self, path):
            
#========================================= Main ==============================================================

search_t_date = '2019-01-31'
search_f_date = '2019-01-01'
query         = 'Giuseppe Conte'
deep = 1000

# =============================================================================
# file_query = regex.sub("_", query)
# path_file = BASE_PATH+file_query+EXT
# 
# s_client = SeleniumClient(BASE_URL)
# 
# tweets_data = s_client.search_date_tweets(query, search_t_date, search_f_date, deep)
# #tweets_data = s_client.search_tweets(query, deep)
# 
# if tweets_data is not None:
#     tweets_df = pd.DataFrame(tweets_data)
#     if (tweets_df is not None):
#         tweets_df.to_csv(path_file, sep='|', encoding = "UTF-8", header=True, index=False)
# 
# df = pd.read_csv(path_file, sep='|', encoding = "UTF-8")
# tweets_no   = df.re_tweet_no
# tweets_uri  = df.re_tweet_uri
# tweets_user = df.User
# 
# for idx in range(len(tweets_no)):
#     tweet_no   = tweets_no[idx]
#     tweet_uri  = tweets_uri[idx]
#     tweet_user = regex.sub('',tweets_user[idx])
#     if (tweet_no is not None and int(tweet_no) >0 ):
#         s_client = SeleniumClient(BASE_URL)
#         tweets_data = s_client.url_tweets(tweet_uri, int(tweet_no))
#         tweets_df = pd.DataFrame(tweets_data)
#         if (tweets_df is not None):
#             
#             path_re_file = BASE_PATH+file_query+'-'+tweet_user+EXT
#             sequence=0
#             while (os.path.isfile(path_re_file)):
#                 sequence +=1
#                 path_re_file = BASE_PATH+file_query+'-'+tweet_user+'_'+str(sequence)+EXT
#             tweets_df.to_csv(path_re_file, sep='|', header=True, index=False)
# 
# 
# =============================================================================
