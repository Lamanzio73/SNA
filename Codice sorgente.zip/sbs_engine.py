#!/usr/bin/env python
# coding: utf-8


# Demo for the Calculation of the Semantic Brand Score - Basic Version
# Read text documents from an example CSV file
import csv
import re
import nltk
import string
from nltk.stem.snowball import SnowballStemmer
from collections import Counter
import numpy as np
import networkx as nx
import pandas as pd

class SBS(object):
    def __init__(self):
        print('init SBS')

    def read_from_file(self, path_file="C:/Basket/RM/Python/SNA/output"):
    	readfile = csv.reader(open(path_file , 'rt',  encoding="utf-8"), delimiter = ";", quoting=csv.QUOTE_NONE)
    	texts = [line[0] for line in readfile]
    	return texts
    
    def read_from_csv(self, path_file):
            df = pd.read_csv(path_file, sep='|', encoding = "UTF-8")
            try:
                messages = df.message
            except Exception as e:
                print(e)
                messages = None
            return messages
    
    def clean_corpus(self, brands, dictionary, texts):
    	# Define stopwords
    	# nltk.download("stopwords")
    	stopw = nltk.corpus.stopwords.words(dictionary) + ['‘','"']
#    	print('stopw', len(stopw))
    	# Define brands (lowercase)
    	text2 = []

    	try:
    		regex = re.compile('[%s]' % re.escape(string.punctuation))
    		pattern = re.compile(r'\b(' + r'|'.join(stopw) + r')\b\s*')
    		for line in texts:
    			if (not pd.isnull(line)):
    				line = line.lower()
                    #Remove words that start with HTTP
    				line = re.sub(r"http\S+", " ", line)
    				line = re.sub(r"www\S+", " ", line)
                    # Remove punctuation
    				line = regex.sub(' ', line)
                    # Remove words made of single letters
    				line = re.sub(r'\b\w{1}\b', ' ', line)
                    # Remove stopwords
    				line = pattern.sub(' ', line)
                    # Remove additional whitespaces
    				line = re.sub(' +',' ',line)
    				line = line.split()
    				text2.append(line)
    
    
    # =============================================================================
    #         texts = [ t if len(t)>=1 else t.lower() for t in texts]
    #         # Remove words that start with HTTP
    #         texts = [re.sub(r"http\S+", " ", t) for t in texts]
    #         # Remove words that start with WWW
    #         texts = [re.sub(r"www\S+", " ", t) for t in texts]
    #         # Remove punctuation
    #         regex = re.compile('[%s]' % re.escape(string.punctuation))
    #         texts = [regex.sub(' ', t) for t in texts]
    #         # Remove words made of single letters
    #         texts = [re.sub(r'\b\w{1}\b', ' ', t) for t in texts]
    #         # Remove stopwords
    #         pattern = re.compile(r'\b(' + r'|'.join(stopw) + r')\b\s*')
    #         texts = [pattern.sub(' ', t) for t in texts]
    #         # Remove additional whitespaces
    #         texts = [re.sub(' +',' ',t) for t in texts]
    #         # Tokenize text documents (becomes a list of lists)
    #         texts = [t.split() for t in texts]
    # 
    # =============================================================================
    	except Exception as e:
    		print("An error occured while fetching: "+ str(e))
    
    	# Snowball Stemming
    	stemmer = SnowballStemmer(dictionary)
    	#stemmer = SnowballStemmer("english")
    	texts = [[stemmer.stem(w) if w not in brands else w for w in t] for t in text2]
    	#print(texts)
    	return texts
    
    def prepare_prevalence(self, brands, texts):
    	# Create a dictionary with frequency counts for each word
    	countPR = Counter()
    	for t in texts:
    		countPR.update(Counter(t))
    
    	# Calculate average score and standard deviation
    	avgPR = np.mean(list(countPR.values()))
    	stdPR = np.std(list(countPR.values()))
    
    	# Calculate standardized Prevalence for each brand
    	PREVALENCE = {}
    	for brand in brands:
    		PREVALENCE[brand] = (countPR[brand] - avgPR) / stdPR
#    		print("Prevalence", brand, PREVALENCE[brand])
    	return PREVALENCE
    
    # Import Networkx
    def prepare_network_graph(self, brands, texts, co_occurence_filter):
        # Choose a co-occurrence range
        co_range = co_occurence_filter
        # Create an undirected Network Graph
        G = nx.Graph()
        # Each word is a network node
        # remove all duplicate
        nodes = set([item for sublist in texts for item in sublist])
        G.add_nodes_from(nodes)
        # Add links based on co-occurrences
        try:
            for doc in texts:
                w_list = []
                length= len(doc)
                for k, w in enumerate(doc):
                    if (k+co_range) >= length: #Define range, based on document length
                        length
                        superior = length ## -> fix bug ceryx
                    else:
                        superior = k+co_range+1
                    #Create the list of co-occurring words
                    if k < length-1:
                        for i in range(k+1,superior):
                            linked_word = doc[i].split()
                            w_list = w_list + linked_word
                            #If the list is not empty, create the network links
                    if w_list:
                        for p in w_list:
                            if G.has_edge(w,p):
                                G[w][p]['weight'] += 1
                            else:
                                G.add_edge(w, p, weight=1)
                    w_list = []
        except Exception as ee:
            print("ERROR: ",ee)
        # Remove negligible co-occurrences based on a filter
        # Create a new Graph which has only links above
        # the minimum co-occurrence threshold
        link_filter = co_occurence_filter
        G_filtered = nx.Graph()
        G_filtered.add_nodes_from(G)
        for u,v,data in G.edges(data=True):
            #print(u,'-', v, '-', data)
            if data['weight'] >= link_filter:
                G_filtered.add_edge(u, v, weight=data['weight'])
        # Optional removal of isolates
        isolates = set(nx.isolates(G_filtered))
        isolates -= set(brands)
        G_filtered.remove_nodes_from(isolates)
        # Check the resulting graph (for small test graphs)
        #G_filtered.nodes()
        # G_filtered.edges(data = True)
#        print("Original Network No. of Nodes:", G.number_of_nodes(), "No. of Edges:", G.number_of_edges())
#        print("Filtered Network No. of Nodes:", G_filtered.number_of_nodes(), "No. of Edges:", G_filtered.number_of_edges())
        network = {}
        network['original']=G
        network['filtered']=G_filtered
        return network

    def prepare_diversity(self, brands, G_filtered):
        # DIVERSITY
#        print('G_filtered', G_filtered)
        DIVERSITY_sequence=dict(nx.degree(G_filtered))
        # Calculate average score and standard deviation
        avgDI = np.mean(list(DIVERSITY_sequence.values()))
        stdDI = np.std(list(DIVERSITY_sequence.values()))
     
        # Calculate standardized Diversity for each brand
        DIVERSITY = {}
        for brand in brands:
            if (brand in DIVERSITY_sequence):
                DIVERSITY[brand] = (DIVERSITY_sequence[brand] - avgDI) / stdDI
#                print("Diversity", brand, DIVERSITY[brand])
        
#        print("DIVERSITY_sequence", DIVERSITY_sequence)
        return DIVERSITY
    
    def prepare_connectivity(self, brands, G_filtered):
        # Define inverse weights 
        for u,v,data in G_filtered.edges(data=True):
            if 'weight' in data and data['weight'] != 0:
                data['inverse'] = 1/data['weight']
            else:
                data['inverse'] = 1   
        
        # CONNECTIVITY
        CONNECTIVITY_sequence=nx.betweenness_centrality(G_filtered, normalized=False, weight ='inverse')
        # Calculate average score and standard deviation
        avgCO = np.mean(list(CONNECTIVITY_sequence.values()))
        stdCO = np.std(list(CONNECTIVITY_sequence.values()))
        
        # cannot divide by zero
        if stdCO == 0.0:
            return
        # Calculate standardized Prevalence for each brand
        CONNECTIVITY = {}
        for brand in brands:
            if (brand in CONNECTIVITY_sequence):
                print('CONNECTIVITY_sequence[brand]', CONNECTIVITY_sequence[brand])
                CONNECTIVITY[brand] = (CONNECTIVITY_sequence[brand] - avgCO) / stdCO
#                print("Connectivity", brand, CONNECTIVITY[brand])
#        print('CONNECTIVITY_sequence', CONNECTIVITY_sequence)
        return CONNECTIVITY
    
    def compute_sbs(self, 
                    texts, 
                    brands, 
                    dictionary, dt_to, co_occurence_filter=2):
    
        # Obtain the Semantic Brand Score of each brand
        total_messages = len(texts)
        texts = self.clean_corpus(brands, dictionary, texts)

        PREVALENCE   = self.prepare_prevalence(brands, texts)
        network      = self.prepare_network_graph(brands, texts, co_occurence_filter)
        G_filtered   = network['filtered']
        DIVERSITY    = self.prepare_diversity(brands, G_filtered)
        CONNECTIVITY = self.prepare_connectivity(brands, G_filtered)
        
        MSG_NO = {}
        BRAND={}
        for brand in brands:
            BRAND[brand]  = brand
            MSG_NO[brand] = total_messages

        DATE={}
        for brand in brands:
            if (dt_to):
                DATE[brand] = dt_to
            else:
                DATE[brand] = ''
        SBS = {}
        for brand in brands:
            if (brand in PREVALENCE and brand in DIVERSITY and brand in CONNECTIVITY):
                SBS[brand] = PREVALENCE[brand] + DIVERSITY[brand] + CONNECTIVITY[brand]
#                print("SBS", brand, SBS[brand])
    
        # Generate a final pandas data frame with all results
        PREVALENCE   = pd.DataFrame.from_dict(PREVALENCE, orient="index", columns = ["PREVALENCE"])
        DIVERSITY    = pd.DataFrame.from_dict(DIVERSITY, orient="index", columns = ["DIVERSITY"])
        CONNECTIVITY = pd.DataFrame.from_dict(CONNECTIVITY, orient="index", columns = ["CONNECTIVITY"])
        SBS          = pd.DataFrame.from_dict(SBS, orient="index", columns = ["SBS"])
        DATE         = pd.DataFrame.from_dict(DATE, orient="index", columns = ["DATE"])
        BRAND        = pd.DataFrame.from_dict(BRAND, orient="index", columns = ["BRAND"])
        MSG_NO       = pd.DataFrame.from_dict(MSG_NO, orient="index", columns = ["MSG_NO"])
        
        SBS = pd.concat([BRAND, PREVALENCE, DIVERSITY, CONNECTIVITY, SBS, MSG_NO, DATE], axis=1, sort=False)
        return SBS


    def prepare_sbs_file(self, 
                    path_file, 
                    brands, 
                    dictionary, dt_to = None, co_occurence_filter=2):
        texts = self.read_from_csv(path_file)
        if (texts is None):
            return None
        return self.compute_sbs(texts, brands, dictionary)

#SBS = SBS().prepare_sbs('C:/Basket/temp/DIMAIO/Di_Maio-1464788840.csv', ['salvini', 'conte', 'di maio'], "italian")
#print(SBS)

 
 
 # =============================================================================
# date_from = None
# date_to = None
# prevalence_1= 
# prevalence_2
# no_nodes
# no_edges
# no_f_nodes
# no_f_edges
# diversity_1
# diversity_2
# dIVERSITY_seq
# connectivity_1
# connectivity_2
# sbs_1
# sbs_2
# 
# print("Original Network\nNo. of Nodes:", G.number_of_nodes(), "No. of Edges:", G.number_of_edges())
# print("Filtered Network\nNo. of Nodes:", G_filtered.number_of_nodes(), "No. of Edges:", G_filtered.number_of_edges())
# 
# 
# 
# sbs_result = {'date_from'    : date_from, 
# 'date_to'      : date_to,
# 'prevalence_1' : prevalence_1,
# 'prevalence_2' : prevalence_2,
# 'no_nodes'     : no_nodes,
# 'no_edges'     : no_edges,
# 'no_f_nodes'   : no_f_nodes,
# 'no_f_edges'   : no_f_edges,
# 'diversity_1'  : diversity_1,
# 'diversity_2'  : diversity_2,
# 'dIVERSITY_seq'  : dIVERSITY_seq,
# 'connectivity_1' : connectivity_1,
# 'connectivity_2' : connectivity_2,
# 'sbs_1' : sbs_1,
# 'sbs_2' : sbs_2}
# 
# 
# =============================================================================


