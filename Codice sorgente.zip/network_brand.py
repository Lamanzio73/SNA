import networkx as nx
import matplotlib.pyplot as plt
import pandas as pd
import sbs_engine as sbs
import warnings
import db_sqlite as sqlite

# Input data files check
from subprocess import check_output

class network_brand(object):
    def __init__(self):
        print('network_brand')

    def process_messages(self, path=None, file_img=None, file_gfx=None, data_msg=None, dictionary=None, title=None, max_words=None, max_font_size=None):
        warnings.filterwarnings('ignore')
        if '_' in title:
            title = title.split('_')[0]
        brands = [title]
        sbs1 = sbs.SBS()
        texts = sbs1.clean_corpus(brands, dictionary, data_msg)
        print('texts no:', len(texts))
        network = sbs1.prepare_network_graph(brands, texts, 2)
        data_msg   = network['filtered']



        G = nx.Graph(day="Master Data Science")
#        for index, row in df_nodes.iterrows():
#            G.add_node(row['name'], group=row['group'], nodesize=row['nodesize'])
#    
#        for index, row in df_edges.iterrows():
#            G.add_weighted_edges_from([(row['source'], row['target'], row['value'])])
    
#        color_map = {'conte':'#f09494', 'salvini':'#eebcbc', 'maio':'#72bbd0', 'berlusconi':'#91f0a1', 'zingaretti':'#629fff'} 
        
        plt.figure(figsize=(10,10))
        options = {
            'edge_color': '#FFDEA2',
            'width': 1,
            'with_labels': True,
            'font_weight': 'regular',
        }
#        colors = [color_map[G.node[node]] for node in G]
#        sizes = [G.node[node]['nodesize']*10 for node in G]
        
        for e in data_msg.nodes():
            if title in e :
#            if e in title  :
#                print(e)
                G.add_node(e)
        for v1,v2, data in data_msg.edges(data=True):
            if title in v1 or title in v2:
#            if v1 in title or v2 in title:
#                print(v1, v2, data)
                wh = int(data['weight'])
                if wh >2 and wh < 6:
                    G.add_weighted_edges_from([(v1, v2, data['weight'])])

        """
        Using the spring layout : 
        - k controls the distance between the nodes and varies between 0 and 1
        - iterations is the number of times simulated annealing is run
        default k=0.1 and iterations=50
        """
        #node_color=colors,  node_size=sizes,
#        nx.draw(subnet_filtered,  pos=nx.spring_layout(subnet_filtered, k=0.2, iterations=50), **options)
#        ax = plt.gca()
#        ax.collections[0].set_edgecolor("#555555") 
#        plt.savefig(base_path+file_name, format="png")
#        plt.show()
#        nx.write_gexf(subnet_filtered,base_path+file_name)
        isolates = set(nx.isolates(G))
        isolates -= set(title)
        G.remove_nodes_from(isolates)
        print ('G nodes', len(G.nodes()))

        if len(G.node) > 0:
            nx.draw(G, pos=nx.spring_layout(G, k=0.25, iterations=50), **options)
            nx.write_gexf(G,path+file_gfx)
            ax = plt.gca()
            ax.collections[0].set_edgecolor("#555555") 
            plt.savefig(path+file_img, format="png")
            plt.show()
        else:
            isolates = set(nx.isolates(data_msg))
            isolates -= set(title)
            data_msg.remove_nodes_from(isolates)
            print ('data_msg  nodes', len(data_msg.nodes()))
            if len(data_msg.node)>0:
                nx.draw(data_msg, pos=nx.spring_layout(data_msg, k=0.25, iterations=50), **options)
                nx.write_gexf(data_msg,path+file_gfx)
                ax = plt.gca()
                ax.collections[0].set_edgecolor("#555555") 
                plt.savefig(path+file_img, format="png")
                plt.show()
                print('Print the filtered')
        return None

###########################################################################################
#BASE_PATH = 'D:/temp/SNA3/'
#file='giuseppe_conte.db'
#
#tables = ['rtw_messages','tw_messages']
#dt_from = '2019-03-01'
#dt_to = '2019-03-10'
#total_sql = []
#
#try:
#    db_engine = sqlite.db_sqlite(BASE_PATH+'giuseppe_conte.db')
#    engine    = db_engine.get_db_file_connection()
#    for table in tables:
#        sql = ' select "message" from "%s" where "date" BETWEEN \'%s\' AND \'%s\';' % (table, dt_from, dt_to)
#        ret_sql    = pd.read_sql_query(sql, con=engine)
#        ret_sql = ret_sql.message
#        no_of_message2 = len(ret_sql)
#        total_sql.extend(ret_sql)
#    engine.close()
#except Exception as e:
#    print (e)
#    engine.close()
#
#data = ' '.join(total_sql)
#ntrk = network_brand()
#ntrk.process_messages(path=BASE_PATH, file_img='result.png', 
#                          file_gfx='result.gexf', data_msg=data, 
#                          dictionary='italian', title='giuseppe_conte', 
#                          max_words=200, max_font_size=40)

