# -*- coding: utf-8 -*-
import re
import time
import tweepy
from tweepy import OAuthHandler
import pandas as pd

"""
Change ACCESS_TOKEN, ACCESS_SECRET, CONSUMER_KEY and CONSUMER_SECRET
to your own. 
"""
query ="Microsoft"

ACCESS_KEY = '1147954133502181376-d9wPoocIUtDFvCrdbuVxL7qC8H942o'
ACCESS_SECRET = 'aCjrs6YlDyb0tgEmMponknZXmhWpOUmsWDlQWCDPhWcUZ'
CONSUMER_KEY = 'F4THZsf1pJshNnqOQtdnEd3yP'
CONSUMER_SECRET = '04QJMxm5Y4iWyFHsWdfCE8INMOcOEsjsRelhHf6AprL7Ap6UWJ'

regex = re.compile(r'[ #@!"£$%&?*+èéç°§ù]')

twitter_api = None
FILE_PATH_TW = 'c:/basket/temp/message.csv'
FILE_PATH_US = 'c:/basket/temp/profile.csv'

class Twitter_API(object):
    def __init__(self, acc_token, acc_secret, cons_token, cons_secret):
        self.ACCESS_TOKEN    = acc_token
        self.ACCESS_SECRET   = acc_secret
        self.CONSUMER_KEY    = cons_token
        self.CONSUMER_SECRET = cons_secret

    def get_twitter_connection(self):
        auth = OAuthHandler(CONSUMER_KEY,CONSUMER_SECRET)
        self.twitter_api = tweepy.API(auth, wait_on_rate_limit=True, 
                         wait_on_rate_limit_notify=True)
        
        auth.set_access_token(ACCESS_KEY, ACCESS_SECRET)

    def tw_search_profile(self, screen_name, user_id):
        data = {
                'id':[],'screen_name':[], 'name':[], 'created_at':[], 'description':[], 'followers_count':[], 'statuses_count':[],
                'url':[], 'location':[], 'lang':[]
        } 

#        profiles = self.twitter_api.lookup_users(screen_names=screen_name)

        full_users = []
        if (screen_name is None):
            screen_name = user_id
        users_count = len(screen_name)
        count = int(users_count / 100) + 1
        while True:
            try:
                for i in range(count):
                    
                    full_users.extend(self.twitter_api.lookup_users(user_ids=screen_name[i*100:min((i+1)*100, users_count)]))
                    #print(screen_name[i*100:min((i+1)*100, users_count)])
                    print ('getting users batch:', i, 'of', count)
                    time.sleep(3)
                break
            except tweepy.TweepError as e:
                print ('Something went wrong, quitting...', e)
                #time.sleep(5 * 10)
                break
#            return full_users
        print('Users found:', len(full_users))
        for user in full_users:
            data['id'].append(user.id)
            data['screen_name'].append(user.screen_name)
            data['name'].append(user.name)
            data['created_at'].append(user.created_at)
            data['description'].append(user.description)
            data['followers_count'].append(user.followers_count)
            data['statuses_count'].append(user.statuses_count)
            data['url'].append(user.url)
            data['location'].append(user.location)
            data['lang'].append(user.lang)
        return data

    def tw_search_msg(self, query, count, since, lang='it'):
        regex = re.compile(r'[\n\r\t]')
        data = {
                'id':[], 'created':[], 'user_id':[], 'geo':[], 'contributors':[], 'coordinates':[],
                'favorited':[], 'reply_screen_name':[], 'reply_status_id':[], 'reply_status_id_str':[], 
                'reply_user_id':[], 'reply_user_id_str':[],
                'place':[], 'retweeted':[], 'retweet_count':[], 'source':[], 'truncated':[], 'text':[]
        } 

        tweet_cursor = tweepy.Cursor(self.twitter_api.search,q=query,count=count, since=since, lang='it').items()
        #until = "2014-02-15",
        for tweet in tweet_cursor:
            print(tweet.created_at)
            data['id'].append(tweet.id)
            data['created'].append(tweet.created_at)
            data['user_id'].append(tweet.user.id)
            data['geo'].append(tweet.geo)
            data['contributors'].append(tweet.contributors)
            data['coordinates'].append(tweet.coordinates) 
            data['favorited'].append(tweet.favorited)
            data['reply_screen_name'].append(tweet.in_reply_to_screen_name)
            data['reply_status_id'].append(tweet.in_reply_to_status_id)
            data['reply_status_id_str'].append(tweet.in_reply_to_status_id_str)
            data['reply_user_id'].append(tweet.in_reply_to_user_id)
            data['reply_user_id_str'].append(tweet.in_reply_to_user_id_str)
            data['place'].append(tweet.place)
            data['retweeted'].append(tweet.retweeted)
            data['retweet_count'].append(tweet.retweet_count)
            data['source'].append(tweet.source)
            data['truncated'].append(tweet.truncated)
            data['text'].append(regex.sub(" ", tweet.text.strip()))
        return data

#test = Twitter_API(ACCESS_KEY, ACCESS_SECRET, CONSUMER_KEY, CONSUMER_SECRET)
#test.get_twitter_connection()

#result = test.tw_search_msg(query="Giuseppe Conte", count=4, since = "2014-02-14",  lang = "it")
#if result is not None:
#    tweets_df = pd.DataFrame(result)
#    tweets_df.to_csv(FILE_PATH_TW, sep='|', encoding = "UTF-8", header=True, index=False)

#result = test.tw_search_profile(screen_name=None, user_id=['558651454'])
#if result is not None:
#    tweets_df = pd.DataFrame(result)
#    tweets_df.to_csv(FILE_PATH_US, sep='|', encoding = "UTF-8", header=True, index=False)


